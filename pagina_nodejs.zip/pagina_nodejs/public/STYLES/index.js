#!/usr/bin/env node

console.log("¡Mi herramienta CLI de Node.js está funcionando!");
